1 ' Conveyor Color Sorting System
2 ' Mapping Reference:
3 ' P1 = jhome | P2 = pickapp | P3 = pick
4 ' P4 = red_app | P5 = redbox | P6 = blue_app | P7 = bluebox
5 Ovrd 20
6 Servo On
7 Mov P1
8 *WAITPART
9 If M_In(1) = 1 Then GoSub *REDBOX
10 If M_In(2) = 1 Then GoSub *BLUEBOX
11 GoTo *WAITPART
12 *REDBOX
13 Mov P2
14 Mvs P3
15 M_Out(6001) = 1
16 Dly 0.5
17 Mov P2
18 Mov P4
19 Mvs P5
20 M_Out(6001) = 0
21 Dly 0.5
22 Mov P4
23 Return
24 *BLUEBOX
25 Mov P2
26 Mvs P3
27 M_Out(6001) = 1
28 Dly 0.5
29 Mov P2
30 Mov P6
31 Mvs P7
32 M_Out(6001) = 0
33 Dly 0.5
34 Mov P6
35 Return
P1=(+0.00,-0.00,+90.00,+0.00,-90.00,+0.00)(,)
P2=(+350.00,-250.00,+300.00,+180.00,+0.00,-90.00)(6,0)
P3=(+350.00,-250.00,+180.00,+180.00,+0.00,-90.00)(6,0)
P4=(+550.00,+200.00,+300.00,+180.00,+0.00,-90.00)(6,0)
P5=(+550.00,+200.00,+180.00,+180.00,+0.00,-90.00)(6,0)
P6=(+150.00,+450.00,+300.00,+180.00,+0.00,-90.00)(6,0)
P7=(+150.00,+450.00,+180.00,+180.00,+0.00,-90.00)(6,0)
