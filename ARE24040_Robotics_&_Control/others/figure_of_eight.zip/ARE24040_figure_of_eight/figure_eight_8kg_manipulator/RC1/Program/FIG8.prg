1 ' P1 is the center point taught manually by the user
2 Mov P1
3 M1 = 50                                 ' Set offset distance (50mm for the loops)
4 ' --- Define Upper Loop Points ---
5 P2 = P1
6 P2.X = P1.X + M1
7 P2.Y = P1.Y + M1
8 P3 = P1
9 P3.Y = P1.Y + (2 * M1)
10 P4 = P1
11 P4.X = P1.X - M1
12 P4.Y = P1.Y + M1
13 ' --- Define Lower Loop Points ---
14 P5 = P1
15 P5.X = P1.X + M1
16 P5.Y = P1.Y - M1
17 P6 = P1
18 P6.Y = P1.Y - (2 * M1)
19 P7 = P1
20 P7.X = P1.X - M1
21 P7.Y = P1.Y - M1
22 ' --- Robot Motion Execution ---
23 JOvrd 50 ' Set jog/run speed to 50% for safety
24 Mvs P1, -50 ' Approach the center point from above (Tool Z offset)
25 Mvs P1      ' Move down to the center point
26 ' Trace the Upper Loop
27 Mvs P2
28 Mvs P3
29 Mvs P4
30 Mvs P1
31 ' Trace the Lower Loop
32 Mvs P5
33 Mvs P6
34 Mvs P7
35 Mvs P1
36 Mvs P1, -50 ' Depart and retract the tool upwards
37 End
P1=(+597.02,+0.01,+1094.40,+179.97,+74.72,+179.97)(7,0)
P2=(+647.02,+50.01,+1094.40,+179.97,+74.72,+179.97)(7,0)
P3=(+597.02,+100.01,+1094.40,+179.97,+74.72,+179.97)(7,0)
P4=(+547.02,+50.01,+1094.40,+179.97,+74.72,+179.97)(7,0)
P5=(+647.02,-49.99,+1094.40,+179.97,+74.72,+179.97)(7,0)
P6=(+597.02,-99.99,+1094.40,+179.97,+74.72,+179.97)(7,0)
P7=(+547.02,-49.99,+1094.40,+179.97,+74.72,+179.97)(7,0)
