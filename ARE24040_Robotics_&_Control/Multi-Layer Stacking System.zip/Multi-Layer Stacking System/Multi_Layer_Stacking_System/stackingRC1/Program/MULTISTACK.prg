1 ' Multi Layer Stacking System
2 ' Position Mapping Reference:
3 ' P1 = jhome | P2 = pick_app | P3 = pick
4 ' P4 = stack_app | P5 = stack base position
5 ' P6 = Dynamic shift layer offset calculation
6 Ovrd 20
7 Servo On
8 Mov P1
9 M1 = 1
10 M2 = 0
11 *STACK
12 Mov P2
13 Mvs P3
14 M_Out(6001) = 1
15 Dly 0.5
16 Mov P2
17 Mov P4
18 ' Initialize shift point to zero and modify the Z-height dynamically
19 P6 = P_Zero
20 P6.Z = -M2
21 ' Execute linear move to stack position offset by Z height
22 Mvs P5 * P6
23 M_Out(6001) = 0
24 Dly 0.5
25 Mov P4
26 M1 = M1 + 1
27 M2 = M2 + 50
28 If M1 <= 5 Then GoTo *STACK
29 Mov P1
30 Servo Off
31 Hlt
P1=(+0.00,-0.00,+90.00,+0.00,-90.00,+0.00)(,)
P2=(+350.00,-300.00,+300.00,+180.00,+0.00,-90.00)(6,0)
P3=(+350.00,-300.00,+170.00,+180.00,+0.00,-90.00)(6,0)
P4=(+150.00,+500.00,+320.00,+180.00,+0.00,-90.00)(6,0)
P6=(0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00)(,)
P5=(+150.00,+500.00,+170.00,+180.00,+0.00,-90.00)(6,0)
