1 Ovrd 20
2 Servo On
3 Def Plt 1,p1s,p1a,p1b,p1d,3,2,1             ' Def Plt Pallet_No,Start,A,B,D,Columns,Rows,Type
4 Mov jhome
5 M1=1
6 *LOOP
7 Pick = Plt 1,M1             'Pick is a runtime-generated position variable,
8 Mov Pick,-120
9 Mvs Pick
10 M_Out(6001)=1
11 Dly 0.5
12 Mvs Pick,-120
13 Mov place,-120
14 Mvs place
15 M_Out(6001)=0
16 Dly 0.5
17 Mvs place,-120
18 M1=M1+1
19 If M1<=6 Then
20     GoTo *LOOP
21 EndIf
22 Mov jhome
23 Servo Off
24 Hlt
25 End '@Pos Begin@ Do not delete this line.
26 '@Pos Comment@ P1S=pallet's starting position
p1s=(+350.00,-500.00,+180.00,+180.00,+0.00,-90.00)(6,0)
p1a=(+350.00,-350.00,+180.00,+180.00,+0.00,-90.00)(6,0)
p1b=(+200.00,-500.00,+180.00,+180.00,+0.00,-90.00)(6,0)
p1d=(+200.00,-350.00,+180.00,+180.00,+0.00,-90.00)(6,0)
Pick=(0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00)(,)
place=(+150.00,+450.00,+180.00,+180.00,+0.00,-90.00)(6,0)
jhome=(+0.00,-0.00,+90.00,+0.00,-90.00,+0.00)
