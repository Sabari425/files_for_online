1 Ovrd 20
2 Servo On
3 Mov jhome
4 Mov pick,-100
5 Mvs pick
6 M_Out(6001)=1
7 Dly 0.5
8 Mvs pick,-100
9 Mov place,-100
10 Mvs place
11 M_Out(6001)=0
12 Dly 0.5
13 Mvs place,-100
14 Mov jhome
15 Servo Off
16 Hlt
pick=(+350.00,-250.00,+180.00,+180.00,+0.00,-90.00)(7,0)
place=(+150.00,+450.00,+180.10,+180.00,+0.00,-90.00)(7,0)
jhome=(+0.00,-0.00,+90.00,+0.00,-90.00,+0.00)
