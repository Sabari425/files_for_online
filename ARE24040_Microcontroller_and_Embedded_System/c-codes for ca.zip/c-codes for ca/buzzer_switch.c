#include<LPC214x.h>
int main (void)
{
PINSEL2 = 0X00000000;
PINSEL0 = 0X00000000;
IO0DIR = 0X00000400;

while(1)
    if(IOPIN1 & 0X02000000)			   
	{
		IOPIN0 = 0X00000400;

	}
	else
	{
           IOPIN0=0X00000000;
	}

}
