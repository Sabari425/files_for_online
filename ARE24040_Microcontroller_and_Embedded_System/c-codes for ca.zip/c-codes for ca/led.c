#include<LPC214x.h>
int main (void)
{
PINSEL2 = 0X00000000;
IO1DIR = 0X00FF0000;
IOPIN1 = 0X00000000;

while(1)			   
	{
		IOPIN1 = 0X00FE0000;

	}

}
