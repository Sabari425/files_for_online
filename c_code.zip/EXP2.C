#include <LPC214x.h>
void delay(int x);
int main(void)
	   {
	   PINSEL2 = 0X00000000;
	   IODIR1 = 0X00FF0000;
	   IOPIN1 = 0X00000000;
	   while(1)
	   {
	   IOPIN1 =0X00000000;
	   delay(1000);
	   IOPIN1=0X00FF0000;
	   delay(1000);
	   }
	   }
void delay(int x)
	{
	unsigned int y,z;
	{
		for(y=x;y>0;y--){
		for(z=0;z<x;z++){
		}
		}
		}
}