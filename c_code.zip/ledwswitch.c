#include <LPC214x.h>
void delay(int x);
int main(void){				  
	PINSEL2 = 0X00000000;
	IODIR1 = 0X00FF0000;
	IOPIN1 = 0X01000000;
	while(1){
	   if(IOPIN1& 0x01000000){
		   IOPIN1=0x00FE0000;
	   }
	   else{
			IOPIN1=0x00FF0000;
	   }
	}
}
void delay(int x){
	unsigned int y,z;
	{
		for(y=x;y>0;y--){
			for(z=0;z<x;z++){}
		}
	}
}